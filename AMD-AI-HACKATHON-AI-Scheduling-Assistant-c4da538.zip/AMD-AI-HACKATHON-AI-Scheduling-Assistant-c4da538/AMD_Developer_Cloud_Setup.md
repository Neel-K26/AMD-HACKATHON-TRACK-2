#### 1. Log in to AMD Digital Ocean with your Email ID [AMD Developer Cloud Login](https://amd.digitalocean.com/login)

#### 2.Select ```GPU Droplets```

<img width="1871" height="1069" alt="image" src="https://github.com/user-attachments/assets/7391ff6b-22bd-4a13-8de2-3c786f0dfbbc" />

#### 3.Click ```Create GPU Droplet``` at the Right 

<img width="1804" height="533" alt="image" src="https://github.com/user-attachments/assets/1f1ac6df-9e7c-432b-8811-64688a557134" />

#### 4.Create GPU Droplet by selecting ```AMD MI300X``` ( Single MI300 GPU ) & Select Snapshot ```Ubuntu_AMD_Hackathon_AI_Scheduling_Assistant```

<img width="1155" height="894" alt="image" src="https://github.com/user-attachments/assets/1736cc99-a6a0-4c5d-82f7-deac30e07122" />

#### 5.Add SSH Key & Select 

<img width="674" height="385" alt="image" src="https://github.com/user-attachments/assets/9a0e2921-dd9c-425f-b28e-c1704baa0a0e" />

<img width="654" height="398" alt="image" src="https://github.com/user-attachments/assets/96f44a78-4121-4b07-a0f6-3a455d7ae672" />

#### 6.And click on ```Create GPU Droplet``` 

<img width="472" height="471" alt="image" src="https://github.com/user-attachments/assets/2d9d82ce-1319-40ed-b3a4-a11984448ee2" />

#### 7.Click on ```Web Console``` at the Top-Right : 

<img width="1249" height="740" alt="image" src="https://github.com/user-attachments/assets/df3e53ff-116e-439b-a3f5-974421efa8de" />


#### 8.You will see a console. You can See IP address & Jupyter Token : 

<img width="1432" height="1060" alt="{6035FF14-CED1-404B-8226-EEFC1EA8B849}" src="https://github.com/user-attachments/assets/09879299-1177-4190-9e97-55503d608ba5" />

#### 9.Copy Paste IP address in Chrome & login with using Jupyter Token 

<img width="1283" height="572" alt="image" src="https://github.com/user-attachments/assets/b0e96dc5-dece-45f1-b88a-3700620a44d3" />

#### 10.Now you have access to Jupyter Lab with all the helper Notebooks : 

<img width="1462" height="1067" alt="{E5FFF69D-3BE2-4EF2-B593-C30D0C59E314}" src="https://github.com/user-attachments/assets/fa1a9795-3a44-4f6d-afbc-df6a1739c5c4" />



