### To access Google Calendar, please follow : [Google Instruction](https://developers.google.com/workspace/calendar/api/quickstart/python)

### Go to the [Google Cloud Console](https://console.cloud.google.com/)

<img width="696" height="720" alt="image" src="https://github.com/user-attachments/assets/b20e61e5-ab9e-4b8c-a61e-e72c1085849f" />

<img width="2406" height="1238" alt="image" src="https://github.com/user-attachments/assets/1b377e90-3afe-4a24-8954-bdd9acb28b6c" />

<img width="991" height="701" alt="image" src="https://github.com/user-attachments/assets/e9bba4a3-7a26-4c34-8d5a-9025ebe72ad7" />

<img width="726" height="574" alt="image" src="https://github.com/user-attachments/assets/56a5db32-6a46-4d33-90ef-1d0d6cbd9258" />

<img width="744" height="530" alt="image" src="https://github.com/user-attachments/assets/628d5780-1a89-47e2-9075-8dd4923c30d3" />

<img width="999" height="701" alt="image" src="https://github.com/user-attachments/assets/7e53d86f-6bb4-4f46-9d65-3cca34984bcd" />

<img width="2388" height="1239" alt="image" src="https://github.com/user-attachments/assets/28742155-a27a-40b9-a8de-695ff4b78342" />

<img width="1288" height="866" alt="image" src="https://github.com/user-attachments/assets/e69b9ff4-0085-4f2f-9da1-75bf028e63ff" />

<img width="1048" height="768" alt="image" src="https://github.com/user-attachments/assets/1a0aeac7-e6de-4fd3-8024-05ad82a11276" />

<img width="1096" height="888" alt="image" src="https://github.com/user-attachments/assets/a6e89e72-ddff-4c95-bbed-c442a95ac859" />

<img width="1022" height="1098" alt="image" src="https://github.com/user-attachments/assets/3734a843-cc9b-4927-96d6-03c13cd5eb95" />

<img width="1024" height="789" alt="image" src="https://github.com/user-attachments/assets/887693b8-78d1-4bbb-b444-b64140b4231e" />

<img width="745" height="636" alt="image" src="https://github.com/user-attachments/assets/d425e4b7-8469-47d7-b2d0-214fdd65f396" />

<img width="781" height="1244" alt="image" src="https://github.com/user-attachments/assets/62d28795-435e-4e82-8bc0-3c5efd310b72" />

<img width="1711" height="1069" alt="image" src="https://github.com/user-attachments/assets/d843c95e-8e7b-4c26-9827-920913c2bc32" />

<img width="1325" height="933" alt="image" src="https://github.com/user-attachments/assets/3ffba9d8-d62c-4f1a-9de8-719685731685" />

<img width="1181" height="861" alt="image" src="https://github.com/user-attachments/assets/cfa8ea1b-801d-4afd-853c-256e150dca6c" />

<img width="1119" height="693" alt="image" src="https://github.com/user-attachments/assets/1eea7527-5d1d-44f6-af27-dc432bb7376b" />

<img width="641" height="838" alt="image" src="https://github.com/user-attachments/assets/c040a34e-8e95-48c9-964b-8f3f1e4a3972" />

<img width="2393" height="850" alt="image" src="https://github.com/user-attachments/assets/b26bf7ff-f63a-4ac1-8b9e-ddd8c47bcf13" />

<img width="2269" height="1044" alt="image" src="https://github.com/user-attachments/assets/7cf65082-ced9-41be-b262-e1ed05127267" />

<img width="1419" height="1233" alt="image" src="https://github.com/user-attachments/assets/25468bea-c8a0-4a12-9759-64fbe7998fe9" />

<img width="919" height="554" alt="image" src="https://github.com/user-attachments/assets/8641e995-b187-48a7-84bb-5c5bd2844e5f" />

<img width="1418" height="1240" alt="image" src="https://github.com/user-attachments/assets/13a2e4ea-3ded-4166-8b65-2cc8f71c3b79" />

<img width="1434" height="634" alt="image" src="https://github.com/user-attachments/assets/7196dbd2-155b-432d-b2d6-71769eff7a8f" />

<img width="1340" height="518" alt="image" src="https://github.com/user-attachments/assets/d7876559-2c3f-4a72-8c81-98360cd566fa" />

<img width="1354" height="575" alt="image" src="https://github.com/user-attachments/assets/f49e0a0c-7a58-4c16-b751-4145c409c892" />

<img width="1348" height="799" alt="image" src="https://github.com/user-attachments/assets/5516271b-ce44-437e-bd6e-cb3a9577cc3e" />

<img width="624" height="158" alt="image" src="https://github.com/user-attachments/assets/d1e67d0c-fe1c-454a-b293-fb4558667224" />

